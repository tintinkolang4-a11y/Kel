# Bowl Busog Website

**One Bowl. Big Busog**

A modern, mobile-friendly, red-themed website for Bowl Busog — a student-centered rice bowl food stall in Brgy. Daanglungsod, Bato, Leyte (near BIST).

## Files
- `index.html` — Main page
- `styles.css` — All styling
- `script.js` — Menu filter + navigation

## How to Use
1. Open `index.html` in any modern browser, or
2. Upload the entire folder to any free hosting (Netlify, Vercel, GitHub Pages, or your school web host).

## Features Included
- Hero section with tagline
- About section with location & contact
- Full Student Lifestyle Menu with category filters (Early Bird, Study Buddy, Night Owl, Power Up, Comfort)
- Pricing from the business proposal
- Why Us section (Bowl Points, Busog Mood Wall, etc.)
- Contact section
- Fully responsive (mobile + desktop)
- Smooth scrolling navigation

## Customization Tips
- Change phone/email in `index.html`
- Add real food photos later (replace emoji icons or add `<img>` tags)
- Update prices or add new menu items easily

Created based on the official Bowl Busog Business Proposal.
